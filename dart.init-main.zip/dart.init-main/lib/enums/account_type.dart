enum AccountType {
  simple,
  premium,
}
